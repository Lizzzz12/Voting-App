const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const axios = require("axios");
require("dotenv").config();

const app = express();
app.use(express.json());
app.use(cors());

// Connect to MongoDB
mongoose.connect("mongodb://localhost:27017/jokesDB", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

// Define the Joke model
const jokeSchema = new mongoose.Schema({
    question: String,
    answer: String,
    votes: [{ value: Number, label: String }],
    availableVotes: [String],
});

const Joke = mongoose.model("Joke", jokeSchema);

// Fetch a random joke from TeeHee API and store it in MongoDB
app.get("/api/joke", async (req, res) => {
    try {
        const response = await axios.get("https://teehee.dev/api/joke");
        const { question, answer } = response.data;

        let joke = new Joke({
            question,
            answer,
            votes: [
                { value: 0, label: "😂" },
                { value: 0, label: "👍" },
                { value: 0, label: "❤️" },
            ],
            availableVotes: ["😂", "👍", "❤️"],
        });

        await joke.save();
        res.json(joke);
    } catch (error) {
        res.status(500).json({ error: "Failed to fetch joke" });
    }
});

// Vote on a joke
app.post("/api/joke/:id", async (req, res) => {
    const { id } = req.params;
    const { emoji } = req.body;

    try {
        let joke = await Joke.findById(id);
        if (!joke) return res.status(404).json({ error: "Joke not found" });

        joke.votes = joke.votes.map(vote =>
            vote.label === emoji ? { ...vote, value: vote.value + 1 } : vote
        );

        await joke.save();
        res.json(joke);
    } catch (error) {
        res.status(500).json({ error: "Failed to vote" });
    }
});

// Start server
app.listen(5000, () => console.log("Server running on port 5000"));
