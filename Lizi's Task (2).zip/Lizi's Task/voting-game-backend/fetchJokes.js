const axios = require("axios");
const mongoose = require("mongoose");
const Joke = require("./models/Joke");

mongoose
  .connect(
    "mongodb+srv://liziko12:liziko12@cluster0.q567m.mongodb.net/jokesDB?retryWrites=true&w=majority&appName=Cluster0"
  )
  .then(() => console.log("✅ MongoDB Connected"))
  .catch((err) => console.error("❌ MongoDB Connection Error:", err));

const fetchJokeFromAPI = async () => {
  try {
    const response = await axios.get("https://teehee.dev/api/joke");
    return response.data.joke; // Extract the joke text 
  } catch (error) {
    console.error("❌ Error fetching joke:", error.message);
    return null;
  }
};

const saveJokeToDB = async () => {
  const jokeText = await fetchJokeFromAPI();
  if (!jokeText) return;

  try {
    const joke = new Joke({ text: jokeText });
    await joke.save();
    console.log(`✅ Saved joke: "${jokeText}"`);
  } catch (error) {
    console.error("❌ Error saving joke:", error.message);
  }
};

const run = async () => {
  for (let i = 0; i < 5; i++) {
    // Fetch 5 jokes
    await saveJokeToDB();
  }
  mongoose.connection.close();
};

run();
