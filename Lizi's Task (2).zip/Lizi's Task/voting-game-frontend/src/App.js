import React from "react";
import JokeComponent from "./pages/Home";


function App() {
    return (
        <div className="App">
            <h1>Voting Game</h1>
            <JokeComponent />
        </div>
    );
}

export default App;
