import React from "react";

const VoteButtons = ({ joke, vote }) => {
  if (!joke) return null; // Ensure joke exists before rendering

  return (
    <div className="mt-4 flex space-x-4">
      <button
        className="px-4 py-2 bg-green-500 text-white rounded"
        onClick={() => vote(joke._id, "😂")}
      >
        😂 Funny
      </button>
      <button
        className="px-4 py-2 bg-red-500 text-white rounded"
        onClick={() => vote(joke._id, "😐")}
      >
        😐 Meh
      </button>
      <button
        className="px-4 py-2 bg-yellow-500 text-white rounded"
        onClick={() => vote(joke._id, "😢")}
      >
        😢 Bad
      </button>
    </div>
  );
};

export default VoteButtons;
