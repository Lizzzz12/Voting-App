import React from 'react';

const JokeCard = ({ joke }) => {
  return (
    <div className="p-6 max-w-md mx-auto bg-white rounded-xl shadow-md text-center">
      <h3 className="text-lg font-semibold">{joke.question}</h3>
      <p className="text-gray-600 mt-2">{joke.answer}</p>
    </div>
  );
};

export default JokeCard;
