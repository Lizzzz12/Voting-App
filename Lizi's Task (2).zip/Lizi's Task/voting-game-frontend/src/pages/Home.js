import React, { useState, useEffect } from "react";
import "./styles.css";

const JokeComponent = () => {
    const [joke, setJoke] = useState(null);
    const [showAnswer, setShowAnswer] = useState(false);
    const [hasVoted, setHasVoted] = useState(false);

    useEffect(() => {
        fetch("http://localhost:5000/api/joke")
            .then(response => response.json())
            .then(data => {
                setJoke(data);
                setShowAnswer(false);
                const votedJokes = JSON.parse(localStorage.getItem("votedJokes")) || [];
                setHasVoted(votedJokes.includes(data._id));
            })
            .catch(error => console.error("Error fetching joke:", error));
    }, []);

    const voteJoke = (emoji) => {
        if (!joke || hasVoted) return;

        fetch(`http://localhost:5000/api/joke/${joke._id}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ emoji }),
        })
        .then(response => response.json())
        .then(updatedJoke => {
            // Update local state to reflect vote count immediately
            setJoke(prevJoke => ({
                ...prevJoke,
                votes: {
                    ...prevJoke.votes,
                    [emoji]: (prevJoke.votes?.[emoji] || 0) + 1
                }
            }));

            setHasVoted(true);
            const votedJokes = JSON.parse(localStorage.getItem("votedJokes")) || [];
            localStorage.setItem("votedJokes", JSON.stringify([...votedJokes, joke._id]));
        })
        .catch(error => console.error("Error voting:", error));
    };

    return (
        <div className="container">
            <div className="joke-container">
                {joke ? (
                    <>
                        <h2>Voting Game</h2>
                        <p>{joke.question}</p>

                        <div className="buttons-container">
                            {!showAnswer ? (
                                <button 
                                    onClick={() => setShowAnswer(true)} 
                                    className="joke-button"
                                >
                                    Show Answer
                                </button>
                            ) : (
                                <p className="joke-answer">{joke.answer}</p>
                            )}

                            <div className="vote-buttons">
                                {joke.availableVotes.map((emoji) => (
                                    <button 
                                        key={emoji} 
                                        onClick={() => voteJoke(emoji)} 
                                        disabled={hasVoted}
                                        className="vote-button"
                                    >
                                        {emoji} ({joke.votes?.[emoji] || 0})
                                    </button>
                                ))}
                            </div>

                            <button 
                                onClick={() => window.location.reload()} 
                                className="next-joke"
                            >
                                Next Joke
                            </button>
                        </div>
                    </>
                ) : (
                    <p>Loading joke...</p>
                )}
            </div>
        </div>
    );
};

export default JokeComponent;
